#!/usr/bin/env bash
set -e

echo "== WeCom Leads Pack Installer =="
echo "默认一路回车即可（直接确认）。"

read -p "安装目录（默认 /opt/wecom-leads-pack）: " APP_DIR
APP_DIR=${APP_DIR:-/opt/wecom-leads-pack}

read -p "端口PORT（默认 3000）: " PORT
PORT=${PORT:-3000}

read -p "管理员用户名ADMIN_USER（默认 admin）: " ADMIN_USER
ADMIN_USER=${ADMIN_USER:-admin}

read -p "管理员密码ADMIN_PASS（默认 123456）: " ADMIN_PASS
ADMIN_PASS=${ADMIN_PASS:-123456}

read -p "企微群机器人Webhook（必填，粘贴后回车）: " WECOM_WEBHOOK
if [ -z "$WECOM_WEBHOOK" ]; then
  echo "Webhook 不能为空。"
  exit 1
fi

echo ""
echo "将安装到：$APP_DIR"
read -p "确认继续？(y/N): " CONFIRM
CONFIRM=${CONFIRM:-y}
if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
  echo "已取消"
  exit 0
fi

# basic checks
command -v node >/dev/null 2>&1 || { echo "未检测到 node，请先安装 Node.js >= 18"; exit 1; }
command -v npm  >/dev/null 2>&1 || { echo "未检测到 npm，请先安装 npm"; exit 1; }

mkdir -p "$APP_DIR"
cp -r ./* "$APP_DIR"/

cd "$APP_DIR"

# write .env
SESSION_SECRET=$(python3 - <<'PY'
import secrets
print(secrets.token_hex(16))
PY
)

cat > .env <<EOF
PORT=$PORT
SESSION_SECRET=$SESSION_SECRET
ADMIN_USER=$ADMIN_USER
ADMIN_PASS=$ADMIN_PASS
WECOM_WEBHOOK=$WECOM_WEBHOOK
EOF

echo "安装依赖中（npm i）..."
npm i --silent

echo ""
echo "安装完成 ✅"
echo "启动方式："
echo "  cd $APP_DIR"
echo "  node server.js"
echo ""
echo "浏览器访问："
echo "  http://你的IP:$PORT/login.html"
