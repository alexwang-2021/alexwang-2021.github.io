# WeCom Leads Pack

- 管理员固定账号登录（默认 admin/123456，可在 .env 改）
- 管理员后台新增员工账号（用户名+密码）
- 员工网页登录录入客户线索（写入 SQLite: data/app.db）
- 每天 09:00 和 15:00 自动汇总“过去24小时新增且未跟进”线索，发送到企微群机器人 Webhook

## 一键安装（在服务器）
1) 上传并解压此包
2) 进入目录执行：
   bash install.sh
一路回车 + 粘贴 webhook + 确认 y

## 启动
node server.js
