const path = require('path');
const fs = require('fs');
const express = require('express');
const session = require('express-session');
const axios = require('axios');
const cron = require('node-cron');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;

const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || '123456';
const WECOM_WEBHOOK = process.env.WECOM_WEBHOOK || '';

/** DB */
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, 'app.db'));

// 建表（兼容老库）
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'staff',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  phone TEXT,
  source TEXT,
  status TEXT DEFAULT 'A',
  biz_type TEXT DEFAULT 'LUOHU',
  assigned_user_id INTEGER,
  last_follow_at TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
`);

// 老库补列（忽略重复列错误）
try { db.exec(`ALTER TABLE leads ADD COLUMN last_follow_at TEXT;`); } catch(e) {}
try { db.exec(`ALTER TABLE leads ADD COLUMN status TEXT DEFAULT 'A';`); } catch(e) {}
try { db.exec(`ALTER TABLE leads ADD COLUMN biz_type TEXT DEFAULT 'LUOHU';`); } catch(e) {}

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// ✅ 30天免登录 + rolling续期（每次访问续30天）
app.use(session({
  secret: process.env.SESSION_SECRET || 'dev-secret-change-me',
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: { maxAge: 30 * 24 * 60 * 60 * 1000 } // 30天
}));

app.use(express.static(path.join(__dirname, 'public')));

function requireLogin(req, res, next) {
  if (req.session?.user) return next();
  return res.redirect('/login.html');
}
function requireAdmin(req, res, next) {
  if (req.session?.user?.role === 'admin') return next();
  return res.status(403).send('Admin only');
}

app.get('/', (req, res) => res.redirect('/login.html'));

/** 登录 */
app.post('/auth/admin_login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    req.session.user = { id: 0, username: ADMIN_USER, role: 'admin' };
    return res.redirect('/admin.html');
  }
  return res.send('管理员账号或密码错误。<a href="/login.html">返回</a>');
});

app.post('/auth/staff_login', (req, res) => {
  const { username, password } = req.body;
  const row = db.prepare(`SELECT id, username, password, role FROM users WHERE username=?`).get(username);
  if (!row) return res.send('员工不存在。<a href="/login.html">返回</a>');
  if ((password || '') !== row.password) return res.send('密码错误。<a href="/login.html">返回</a>');

  req.session.user = { id: row.id, username: row.username, role: row.role };
  return res.redirect('/form.html');
});

app.get('/logout', (req, res) => req.session.destroy(() => res.redirect('/login.html')));

/** 管理员：用户管理 */
app.get('/api/admin/users', requireLogin, requireAdmin, (req, res) => {
  const rows = db.prepare(`SELECT id, username, role, created_at FROM users ORDER BY id DESC`).all();
  res.json(rows);
});

app.post('/api/admin/users', requireLogin, requireAdmin, (req, res) => {
  const { username, password, role } = req.body;
  if (!username || !password) return res.status(400).json({ ok:false, msg:'username/password required' });
  try {
    db.prepare(`INSERT INTO users(username,password,role) VALUES(?,?,?)`)
      .run(username, password, role === 'admin' ? 'admin' : 'staff');
    res.json({ ok:true });
  } catch (e) {
    res.status(400).json({ ok:false, msg:String(e.message || e) });
  }
});

/** A/B/C/D/E 对应跟进天数 */
function intervalDays(status) {
  return ({ A: 1, B: 3, C: 7, D: 30, E: 999999 }[status] ?? 1);
}
function statusLabel(status) {
  const s = (status || 'A').toUpperCase();
  if (s === 'E') return 'E（无效）';
  return `${s}（${intervalDays(s)}天）`;
}
function bizLabel(biz) {
  const b = (biz || 'LUOHU').toUpperCase();
  return b === 'GAOXIN' ? '高新' : (b === 'LUOHU' ? '落户' : b);
}
function daysSince(dtStr) {
  if (!dtStr) return 999999;
  const dt = new Date(dtStr.replace(' ', 'T'));
  return Math.floor((Date.now() - dt.getTime()) / 86400000);
}

/** 录入线索（手机/来源可空；新增 biz_type；status A~E） */
app.post('/api/leads', requireLogin, (req, res) => {
  const { name, phone, source, status, biz_type, assigned_user_id } = req.body;

  let ownerId = req.session.user.role === 'admin'
    ? (assigned_user_id ? Number(assigned_user_id) : null)
    : req.session.user.id;

  const st = (status || 'A').toUpperCase();
  const biz = (biz_type || 'LUOHU').toUpperCase();

  db.prepare(`
    INSERT INTO leads(name, phone, source, status, biz_type, assigned_user_id)
    VALUES(?,?,?,?,?,?)
  `).run(
    name || '',
    phone || '',          // ✅ 可空
    source || '',         // ✅ 可空
    st,
    biz,
    ownerId
  );

  res.send('提交成功 ✅ <a href="/form.html">继续录入</a> | <a href="/my/leads" target="_blank">查看我的客户</a> | <a href="/logout">退出</a>');
});

/** 标记已跟进 */
app.post('/api/leads/:id/follow', requireLogin, (req, res) => {
  const id = Number(req.params.id);
  db.prepare(`UPDATE leads SET last_follow_at=datetime('now','localtime') WHERE id=?`).run(id);
  res.json({ ok:true });
});

/** 管理员：HTML列表（默认只看该跟进；?all=1 看全部；?biz=GAOXIN/LUOHU 筛选） */
app.get('/admin/leads', requireLogin, requireAdmin, (req, res) => {
  const showAll = req.query.show === 'all';   // 查看全部（含无效）
  const onlyE = req.query.only === 'E';       // ✅ 只看无效（E类）
  const bizFilter = (req.query.biz || '').toUpperCase();

  const rows = db.prepare(`
    SELECT l.*, u.username AS owner
    FROM leads l
    LEFT JOIN users u ON u.id = l.assigned_user_id
    ORDER BY l.id DESC
    LIMIT 500
  `).all();

  const filtered = rows.filter(r => {
    const st = String(r.status || 'A').toUpperCase();
    const biz = String(r.biz_type || 'LUOHU').toUpperCase();
  
    // 业务类型过滤
    if (bizFilter && biz !== bizFilter) return false;
  
    // ✅ 只看无效（唯一能看到 E 的地方）
    if (onlyE) return st === 'E';
  
    // ❌ 其他任何视图，都不显示无效
    if (st === 'E') return false;
  
    // 只看该跟进
    if (!showAll) {
      const base = r.last_follow_at || r.created_at;
      return daysSince(base) >= intervalDays(st);
    }
  
    // 查看全部（A/B/C/D 全部）
    return true;
  });
  

  const htmlRows = filtered.map(r => {
    const st = String(r.status || 'A').toUpperCase();
    const base = r.last_follow_at || r.created_at;
    const dueIn = intervalDays(st) - daysSince(base);
    const dueText = dueIn <= 0 ? '✅ 该跟进' : `还有 ${dueIn} 天`;

    return `
      <tr>
        <td>${r.id}</td>
        <td>${statusLabel(st)}</td>
        <td>${bizLabel(r.biz_type)}</td>
        <td>${r.name || ''}</td>
        <td>${r.phone || ''}</td>
        <td>${r.source || ''}</td>
        <td>${r.owner || '未分配'}</td>
        <td>${r.created_at || ''}</td>
        <td>${r.last_follow_at || ''}</td>
        <td>${dueText}</td>
        <td><button onclick="follow(${r.id})">标记已跟进</button></td>
      </tr>`;
  }).join('');

  res.send(`<!doctype html>
  <html><head><meta charset="utf-8"><title>客户列表</title></head>
  <body>
    <h2>客户列表</h2>
    <p>
      <a href="/admin/leads">只看该跟进</a> |
      <a href="/admin/leads?show=all">查看全部（含无效）</a> |
      <a href="/admin/leads?only=E">查看无效客户（E类）</a> |
      <a href="/admin/leads?biz=LUOHU">只看落户</a> |
      <a href="/admin/leads?biz=GAOXIN">只看高新</a> |
      <a href="/admin.html">返回后台</a> |
      <a href="/logout">退出</a>
    </p>

    <table border="1" cellpadding="6" cellspacing="0">
      <thead>
        <tr>
          <th>ID</th><th>跟进级别</th><th>业务类型</th><th>姓名</th>
          <th>手机</th><th>来源</th><th>负责人</th>
          <th>创建时间</th><th>上次跟进</th><th>状态</th><th>操作</th>
        </tr>
      </thead>
      <tbody>${htmlRows || '<tr><td colspan="11">暂无数据</td></tr>'}</tbody>
    </table>

    <script>
      async function follow(id){
        await fetch('/api/leads/' + id + '/follow', { method:'POST' });
        location.reload();
      }
    </script>
  </body></html>`);
});

/** 员工：HTML列表（只看自己名下；?biz=GAOXIN/LUOHU 筛选） */
app.get('/my/leads', requireLogin, (req, res) => {
  const uid = req.session.user.id;
  const bizFilter = (req.query.biz || '').toUpperCase();

  const rows = db.prepare(`
    SELECT l.*
    FROM leads l
    WHERE l.assigned_user_id = ?
    ORDER BY l.id DESC
    LIMIT 500
  `).all(uid);

  const htmlRows = rows
    .filter(r => {
      const st = String(r.status||'A').toUpperCase();
      const biz = String(r.biz_type||'LUOHU').toUpperCase();
      if (st === 'E') return false;
      if (bizFilter && biz !== bizFilter) return false;
      return true;
    })
    .map(r => {
      const st = String(r.status || 'A').toUpperCase();
      const base = r.last_follow_at || r.created_at;
      const dueIn = intervalDays(st) - daysSince(base);
      const dueText = dueIn <= 0 ? '✅ 该跟进' : `还有 ${dueIn} 天`;
      return `
        <tr>
          <td>${r.id}</td>
          <td>${statusLabel(st)}</td>
          <td>${bizLabel(r.biz_type)}</td>
          <td>${r.name||''}</td>
          <td>${r.phone||''}</td>
          <td>${r.source||''}</td>
          <td>${r.created_at||''}</td>
          <td>${r.last_follow_at||''}</td>
          <td>${dueText}</td>
          <td><button onclick="follow(${r.id})">标记已跟进</button></td>
        </tr>`;
    }).join('');

  res.send(`<!doctype html>
  <html><head><meta charset="utf-8"><title>我的客户</title></head>
  <body>
    <h2>我的客户列表</h2>
    <p>
      <a href="/form.html">返回录入</a> |
      <a href="/my/leads?biz=LUOHU">只看落户</a> |
      <a href="/my/leads?biz=GAOXIN">只看高新</a> |
      <a href="/logout">退出</a>
    </p>
    <table border="1" cellpadding="6" cellspacing="0">
      <thead>
        <tr>
          <th>ID</th><th>跟进级别</th><th>业务类型</th><th>姓名</th><th>手机</th><th>来源</th>
          <th>创建时间</th><th>上次跟进</th><th>跟进状态</th><th>操作</th>
        </tr>
      </thead>
      <tbody>${htmlRows || '<tr><td colspan="10">暂无数据</td></tr>'}</tbody>
    </table>
    <script>
      async function follow(id){
        await fetch('/api/leads/' + id + '/follow', { method:'POST' });
        location.reload();
      }
    </script>
  </body></html>`);
});

/** 定时推送：只推“该跟进”的 A/B/C/D（E不推），并按业务类型分组 */
async function pushSummary() {
  if (!WECOM_WEBHOOK) return;

  const rows = db.prepare(`
    SELECT l.*, u.username AS owner
    FROM leads l
    LEFT JOIN users u ON u.id = l.assigned_user_id
    WHERE UPPER(COALESCE(l.status,'A')) != 'E'
    ORDER BY l.id DESC
    LIMIT 800
  `).all();

  const due = rows.filter(r => {
    const st = String(r.status || 'A').toUpperCase();
    const base = r.last_follow_at || r.created_at;
    return daysSince(base) >= intervalDays(st);
  }).slice(0, 80);

  if (!due.length) return;

  const groups = { GAOXIN: [], LUOHU: [], OTHER: [] };
  for (const r of due) {
    const biz = String(r.biz_type || 'LUOHU').toUpperCase();
    if (biz === 'GAOXIN') groups.GAOXIN.push(r);
    else if (biz === 'LUOHU') groups.LUOHU.push(r);
    else groups.OTHER.push(r);
  }

  function fmtList(list) {
    return list.map(r => {
      const st = String(r.status || 'A').toUpperCase();
      return `#${r.id} ${statusLabel(st)} ${r.name||''} ${r.phone||''} 来源:${r.source||''} 负责人:${r.owner||'未分配'} 上次:${r.last_follow_at||'无'}`;
    }).join('\n');
  }

  let text = `【待跟进客户提醒】共 ${due.length} 条\n`;
  if (groups.GAOXIN.length) text += `\n【高新】${groups.GAOXIN.length}条\n` + fmtList(groups.GAOXIN) + '\n';
  if (groups.LUOHU.length)  text += `\n【落户】${groups.LUOHU.length}条\n` + fmtList(groups.LUOHU) + '\n';
  if (groups.OTHER.length)  text += `\n【其他】${groups.OTHER.length}条\n` + fmtList(groups.OTHER) + '\n';

  await axios.post(WECOM_WEBHOOK, { msgtype:"text", text:{ content:text } });
}

cron.schedule('0 9 * * *',  () => pushSummary().catch(console.error), { timezone:'Asia/Shanghai' });
cron.schedule('0 15 * * *', () => pushSummary().catch(console.error), { timezone:'Asia/Shanghai' });

app.listen(PORT, () => console.log(`Server running: http://0.0.0.0:${PORT}/login.html`));
